<?php
/**
 * مقادیر پیش‌فرض تنظیمات، تم‌ها و جایگاه‌های تبلیغ
 */

function default_settings(): array
{
    return [
        // عمومی
        'site_title' => 'NEXUS | HUB',
        'site_tagline' => 'گیم | تکنولوژی | ادیت | موزیک | سرگرمی | اخبار روز',
        'site_description' => 'NEXUS | HUB — محتوای روزانه، کاربردی و متفاوت در دنیای گیم، تکنولوژی، ادیت، موزیک و اخبار روز.',
        'meta_keywords' => 'گیم, تکنولوژی, اخبار بازی, اخبار تکنولوژی, نکسوس',
        'logo' => 'assets/img/nx-logo-512.png',
        'favicon' => 'assets/img/nx-favicon.png',
        'contact_email' => '',
        'posts_per_page' => '12',
        'footer_text' => 'NEXUS | HUB — محتوای روزانه، کاربردی و متفاوت 🔥 به کامیونیتی NEXUS بپیوندید.',
        'copyright' => 'تمامی حقوق برای NEXUS | HUB محفوظ است.',
        'trust_badges' => '[]',
        // site texts & section switches (Appearance > Texts)
        'brand_sub' => 'Gaming · Tech · News',
        'hdr_tg_on' => '1',
        'topbar_on' => '1',
        'footer_brand_on' => '1',
        'footer_brand_social' => '1',
        'topbar_date_on' => '1',
        'topbar_social_on' => '1',
        'hdr_search_on' => '1',
        'hdr_login_on' => '1',
        'hdr_tg_label' => 'عضویت در کانال',
        'hdr_login_label' => 'ورود | ثبت‌نام',
        'footer_cats_title' => 'دسته‌بندی‌ها',
        'footer_links_title' => 'دسترسی سریع',
        'footer_raffle_link' => '1',
        'footer_wheel_link' => '1',
        'raffle_ended_access' => 'winners',
        'prize_claim_on' => '1',
        'link_prizes_footer' => '0',
        'link_notifs_footer' => '0',
        'link_prizes_drawer' => '1',
        'bookmarks_on' => '1',
        'sales_closed_upto' => '',
        // shipping (physical products)
        'ship_methods' => json_encode([['name' => 'پست پیشتاز', 'cost' => 70000, 'days' => '۳ تا ۵ روز کاری'], ['name' => 'تیپاکس', 'cost' => 120000, 'days' => '۱ تا ۲ روز کاری'], ['name' => 'پیک (فقط شهر خودمون)', 'cost' => 90000, 'days' => 'همان روز']], JSON_UNESCAPED_UNICODE),
        'ship_free_over' => '0',
        'ship_track_url' => 'https://tracking.post.ir/?id={code}',
        'ship_note' => '',
        'ship_postcode_req' => '1',
        'export_db' => '1',
        'export_safe' => '1',
        'export_uploads' => '0',
        'link_saved_drawer' => '1',
        'link_saved_footer' => '0',
        'link_notifs_drawer' => '1',
        'prize_claim_hours' => '24',
        'prize_claim_ids' => '',
        'footer_cta_on' => '1',
        'footer_cta_btn' => 'کانال تلگرام',
        'vmsg_check' => 'برای ادامه، این گزینه رو تیک بزن ✅',
        'vmsg_field' => 'این قسمت رو پر کن ✍️',
        'vmsg_email' => 'یه ایمیل درست بنویس، مثل name@gmail.com',
        'vmsg_short' => 'باید دست‌کم {n} کاراکتر باشه',
        'tgblock_eyebrow' => 'کانال رسمی تلگرام',
        'tgblock_title' => 'به کامیونیتی NEXUS بپیوند 💬',
        'tgblock_text' => 'محتوای روزانه، کاربردی و متفاوت 🔥 — گیم 🎮 | تکنولوژی 💻 | ادیت 🎬 | موزیک 🎵 | سرگرمی 🎉 | اخبار روز 📰',
        'tgblock_btn' => 'عضویت در کانال',
        'tgblock_group_btn' => 'گروه گفتگو',
        'contact_style' => 'icons',
        'footer_cta_title' => 'همیشه یک قدم جلوتر باش',
        'footer_cta_text' => 'جدیدترین اخبار گیم و تکنولوژی رو زودتر از همه توی تلگرام بخون.',
        'footer_made' => 'Designed with ❤ for NEXUS',
        'to_top_on' => '1',
        'perf_widget_on' => '1',
        'warp_on' => '1',
        'auth_tagline' => 'دروازه‌ی ورود به کامیونیتی NEXUS 🔥',
        'auth_btn_label' => 'ورود و ثبت‌نام',
        'auth_back_label' => 'بازگشت به سایت',
        'auth_welcome_title' => 'خوش اومدی 👋',
        'auth_welcome_text' => 'شماره موبایل، ایمیل یا نام کاربری‌ات رو وارد کن. اگه حساب داشته باشی وارد می‌شی، نداشته باشی حسابت رو می‌سازیم.',
        'og_image' => '',
        'google_verify' => '',
        'seo_https' => '1',
        'seo_alt_names' => 'NexusHub, Nexus Hub, نکسوس هاب, نکسوس, NexusHubIR',
        'seo_home_title' => '',
        'seo_site_name' => '',
        'seo_index_authors' => '0',
        'indexnow_on' => '1',
        'news_sitemap_on' => '1',
        'robots_extra' => '',
        'verify_files' => "35243901.txt\n35691018.txt",
        'trust_title' => 'نمادهای اعتماد',
        'show_online' => '1',

        // شبکه‌های اجتماعی
        'social_telegram' => 'https://t.me/NexusHubIR',
        'social_group' => 'https://t.me/NexusHubIR_Group',
        'social_admin' => 'https://t.me/XaSina',
        'social_instagram' => '',
        'social_x' => '',
        'social_youtube' => '',
        'social_aparat' => '',

        // ظاهر
        'theme_preset' => 'nexus',
        'color_primary' => '#ff1f3d',
        'color_secondary' => '#ff7a3d',
        'color_bg' => '#050507',
        'glass_blur' => '18',
        'glass_opacity' => '55',
        'radius' => '20',
        'card_style' => 'glass',
        'theme_decor' => 'auto',      // auto (از تم) | off | یکی از decor_types
        'decor_admin' => '1',
        'decor_density' => '18',
        'hero_style' => 'magazine',   // magazine | slider | grid
        'bg_effect' => 'particles',   // particles | grid | aurora | matrix | none
        'font_scale' => '100',
        'anim_preloader' => '1',
        'anim_cursor' => '1',
        'anim_tilt' => '1',
        'anim_reveal' => '1',
        'anim_glitch' => '1',
        'anim_noise' => '1',
        'show_stories' => '1',
        'show_ticker' => '1',
        'ticker_label' => 'فوری',
        'ticker_speed' => '40',
        'announce_on' => '1',
        'announce_text' => '🎰 قرعه‌کشی ویژه شروع شد! برای شرکت به کانال تلگرام NEXUS بپیوندید 🧸',
        'announce_link' => 'https://t.me/NexusHubIR',
        'announce_style' => 'pinned', // pinned | gradient | glitch
        // home page texts & counts, sidebar widgets
        'home_latest_title' => 'آخرین اخبار',
        'home_latest_more' => 'همه اخبار',
        'home_latest_btn' => 'مشاهده اخبار بیشتر',
        'home_cat_count' => '6',
        'home_trend_title' => 'پربازدیدترین‌ها',
        'home_trend_count' => '4',
        'home_shop_count' => '4',
        'wide_single' => 'half',        // a lone box in a wide place: half = half width, centred · full = full width
        'sidebar_widgets' => json_encode([['key' => 'trend', 'on' => 1], ['key' => 'ads', 'on' => 1], ['key' => 'telegram', 'on' => 1], ['key' => 'tags', 'on' => 1]]),
        'sb_trend_title' => 'داغ‌ترین‌ها',
        'sb_trend_count' => '5',
        'sb_tg_title' => '',
        'sb_tg_text' => '',
        'sb_tg_btn' => 'عضویت در کانال',
        'sb_tags_title' => 'برچسب‌های داغ',
        'sb_tags_count' => '16',
        'home_sections' => json_encode([
            ['key' => 'hero', 'on' => 1],
            ['key' => 'latest', 'on' => 1],
            ['key' => 'categories', 'on' => 1],
            ['key' => 'trending', 'on' => 1],
            ['key' => 'telegram', 'on' => 1],
            ['key' => 'shop', 'on' => 1],
        ]),
        'menu' => json_encode([
            ['title' => 'خانه', 'url' => '/'],
            ['title' => 'همه اخبار', 'url' => '/archive'],
            ['title' => 'گیم', 'url' => '/category/game'],
            ['title' => 'تکنولوژی', 'url' => '/category/tech'],
            ['title' => 'سرگرمی', 'url' => '/category/fun'],
            ['title' => 'تماس', 'url' => '/contact'],
        ], JSON_UNESCAPED_UNICODE),
        'custom_css' => '',
        'head_code' => '',
        'footer_code' => '',

        // نظرات و واکنش‌ها
        'members_register' => '1',
        'captcha_site' => '1',          // security code on the site's sign-in and sign-up
        'captcha_admin' => '1',         // security code on the panel sign-in
        'captcha_len' => '5',
        'admin_gate_on' => '0',         // hidden panel entrance (turned on from the panel, after the link is copied)
        'admin_gate_key' => '',
        'admin_gate_hash' => '',
        'admin_idle_min' => '120',      // panel sign-out after this many idle minutes
        'admin_login_log' => '[]',
        'comments_enabled' => '1',
        'comments_moderation' => '1',
        'reactions_enabled' => '1',
        'reactions_list' => '🔥,❤️,😂,😮,😭,👍',
        'trending_days' => '30',
        'archive_per_page' => '9',
        'latest_mode' => 'count',   // count | hours | since
        'latest_count' => '12',
        'latest_hours' => '72',
        'latest_since' => '',

        // تلگرام
        'tg_bot_token' => '',
        'tg_chat_id' => '@NexusHubIR',
        'tg_autopost' => '0',
        'tg_template' => "🧩 <b>{title}</b>\n\n{excerpt}\n\n🔗 {link}\n\n📢 {channel}",

        // سایر
        'maintenance' => '0',
        'maintenance_text' => 'سایت در حال بروزرسانی است؛ به زودی برمی‌گردیم 🔧',
        'ad_label' => 'تبلیغ',
        'post_middle_paragraph' => '3',

        // فروشگاه
        'shop_enabled' => '1',
        'shop_title' => 'فروشگاه NEXUS',
        'shop_seo_title' => '', 'shop_seo_desc' => '', 'shop_seo_keywords' => '', 'shop_seo_image' => '',
        'shop_tagline' => 'پریمیوم تلگرام، استارز، تون و هر چیزی که لازم داری — سریع، امن و با پشتیبانی واقعی',
        'shop_card_number' => '6219861939982061',
        'shop_card_name' => 'مهدیه عباس زاده',
        'shop_card_bank' => 'بانک سامان',
        'shop_usd_mode' => 'manual',      // manual | auto (قیمت تتر نوبیتکس)
        'shop_usd_rate' => '0',           // قیمت دلار به تومان (دستی)
        'shop_ton_mode' => 'auto',        // auto | manual
        'shop_ton_usd' => '0',            // قیمت دستی / پشتیبان هر تون به دلار
        'shop_margin' => '0',             // درصد سود روی قیمت‌های دلاری و تونی
        'shop_round' => '1000',           // گرد کردن قیمت نهایی (رو به بالا)
        'shop_pay_minutes' => '60',
        'shop_notice' => 'پس از واریز، تصویر فیش را ارسال کنید. سفارش‌ها معمولاً بین ۵ تا ۳۰ دقیقه انجام می‌شوند.',
        'shop_terms' => "• سفارش پس از تایید فیش واریزی انجام می‌شود.\n• اطلاعات تحویل (مثل آیدی تلگرام) را با دقت وارد کنید؛ مسئولیت اطلاعات اشتباه با خریدار است.\n• در صورت عدم امکان انجام سفارش، مبلغ کامل به کارت شما برگشت داده می‌شود.\n• برای پیگیری از بخش پشتیبانی تیکت ثبت کنید.",
        'shop_in_header' => '1',
        'shop_in_mobile' => '1',
        'shop_in_footer' => '1',
        'shop_menu_label' => 'فروشگاه',
        'shop_banner_on' => '1',
        'shop_banner_title' => 'فروشگاه NEXUS افتتاح شد 🛍️',
        'shop_banner_text' => 'پریمیوم تلگرام، استارز و تون با بهترین قیمت؛ پرداخت کارت‌به‌کارت و تحویل سریع.',
        'shop_banner_btn' => 'ورود به فروشگاه',
        'shop_banner_style' => 'flow',    // یکی از تم‌های تبلیغ
        'shop_banner_places' => 'sidebar,post_bottom',
        'shop_banner_emoji' => '🛍️',
        'shop_banner_accent' => '',
        'shop_banner_image' => '',
        'shop_banner_badge' => 'جدید',
        'shop_support_on' => '1',
        'auth_skin' => 'nebula',            // nebula | glass | neon | aurora | gold | paper — the sign-in box, fields and buttons
        'auth_logo_style' => 'particles',   // particles | laser | glass (صفحه ورود)
        'shop_tickers_on' => '1',
        'shop_tickers' => 'usd,gold18,btc,eth',
        'shop_tg_admin_chat' => '',
        'shop_rate_cache' => '',
    ];
}

/** انواع محصول فروشگاه + فیلدهای پیش‌فرض هر نوع */
function product_types(): array
{
    $tgUser = ['key' => 'tg_username', 'label' => 'آیدی تلگرام گیرنده', 'type' => 'username', 'required' => 1, 'placeholder' => '@username'];
    // delivery: manual (you deliver by hand) · ship (sent by post, the address is taken) · codes (a code from the pool goes out by itself) · link (a link / text goes out by itself)
    return [
        'premium' => ['name' => 'پریمیوم تلگرام', 'icon' => '⭐', 'color' => '#a855f7', 'fields' => [$tgUser], 'delivery' => 'manual', 'unit' => 'عدد', 'desc' => 'فعال‌سازی روی آیدی مشتری'],
        'stars' => ['name' => 'استارز تلگرام', 'icon' => '🌟', 'color' => '#ffc53d', 'fields' => [$tgUser], 'delivery' => 'manual', 'unit' => 'عدد', 'desc' => 'هر تعداد، با قیمت لحظه‌ای'],
        'ton' => ['name' => 'تون (TON)', 'icon' => '💎', 'color' => '#0098ea', 'fields' => [['key' => 'wallet', 'label' => 'آدرس کیف پول TON', 'type' => 'text', 'required' => 1, 'placeholder' => 'UQ... یا EQ...']], 'delivery' => 'manual', 'unit' => 'TON', 'desc' => 'واریز به کیف پول مشتری'],
        'giftcard' => ['name' => 'گیفت کارت', 'icon' => '🎁', 'color' => '#ff3d8b', 'fields' => [], 'delivery' => 'codes', 'unit' => 'عدد', 'desc' => 'کد خودکار بعد از تایید پرداخت'],
        'license' => ['name' => 'لایسنس / کد فعال‌سازی', 'icon' => '🔑', 'color' => '#1de9b6', 'fields' => [], 'delivery' => 'codes', 'unit' => 'عدد', 'desc' => 'ویندوز، آنتی‌ویروس، نرم‌افزار…'],
        'game' => ['name' => 'بازی / آیتم گیم', 'icon' => '🎮', 'color' => '#ff1f3d', 'fields' => [['key' => 'account', 'label' => 'ایمیل یا آیدی اکانت', 'type' => 'text', 'required' => 1, 'placeholder' => '']], 'delivery' => 'manual', 'unit' => 'عدد', 'desc' => 'سی‌پی، یوسی، جم، اکانت…'],
        'account' => ['name' => 'اکانت / اشتراک', 'icon' => '🪪', 'color' => '#22c55e', 'fields' => [], 'delivery' => 'manual', 'unit' => 'عدد', 'desc' => 'اسپاتیفای، نتفلیکس، VPN…'],
        'digital' => ['name' => 'فایل دانلودی', 'icon' => '📥', 'color' => '#6366f1', 'fields' => [], 'delivery' => 'link', 'unit' => 'عدد', 'desc' => 'کتاب، قالب، پریست، موزیک…'],
        'course' => ['name' => 'دوره آموزشی', 'icon' => '🎓', 'color' => '#0ea5e9', 'fields' => [], 'delivery' => 'link', 'unit' => 'عدد', 'desc' => 'لینک دسترسی بعد از خرید'],
        'physical' => ['name' => 'کالای فیزیکی', 'icon' => '📦', 'color' => '#f97316', 'fields' => [], 'delivery' => 'ship', 'unit' => 'عدد', 'desc' => 'ارسال پستی با آدرس مشتری'],
        'fashion' => ['name' => 'پوشاک و کفش', 'icon' => '👕', 'color' => '#ec4899', 'fields' => [['key' => 'size', 'label' => 'سایز', 'type' => 'select', 'required' => 1, 'options' => 'S,M,L,XL,XXL']], 'delivery' => 'ship', 'unit' => 'عدد', 'desc' => 'با انتخاب سایز و رنگ'],
        'service' => ['name' => 'خدمات', 'icon' => '🛠️', 'color' => '#3dbbff', 'fields' => [['key' => 'details', 'label' => 'توضیح کار', 'type' => 'textarea', 'required' => 0, 'placeholder' => '']], 'delivery' => 'manual', 'unit' => 'ساعت', 'desc' => 'طراحی، تعمیر، مشاوره…'],
        'other' => ['name' => 'سایر', 'icon' => '🛍️', 'color' => '#ff7a3d', 'fields' => [], 'delivery' => 'manual', 'unit' => 'عدد', 'desc' => 'هر چیز دیگه‌ای'],
    ];
}

/** how an order item reaches the buyer */
function auth_skins(): array
{
    return [
        'nebula' => ['🌌 سحابی (پیش‌فرض)', 'شیشه‌ی تیره با حاشیه‌ی رنگ تم', 'linear-gradient(160deg,#2a0d16,#0b0910)', 'linear-gradient(135deg,var(--primary),var(--secondary))'],
        'glass' => ['🧊 شیشه‌ای یخی', 'شیشه‌ی مات روشن با دکمه‌ی سفید', 'linear-gradient(160deg,rgba(255,255,255,.22),rgba(255,255,255,.06))', 'linear-gradient(180deg,#fff,#e6e9f2)'],
        'neon' => ['⚡ سایبر نئونی', 'گوشه‌های بریده، خط زیر فیلدها، دکمه‌ی نئونی', '#05060b', 'transparent'],
        'aurora' => ['🌈 شفق قطبی', 'رنگ‌های شفق متحرک و فیلدهای گرد', 'linear-gradient(160deg,#0e2a44,#2a1450)', 'linear-gradient(110deg,#22d3ee,#a78bfa,#f472b6)'],
        'gold' => ['👑 لوکس طلایی', 'مشکی و طلایی، مثل کارت VIP', 'linear-gradient(165deg,#1b1407,#050505)', 'linear-gradient(135deg,#f7e08e,#d4af37,#a67c00)'],
        'paper' => ['📄 روشن مینیمال', 'کارت سفید و تمیز روی پس‌زمینه‌ی تیره', '#fbfbfd', 'linear-gradient(135deg,var(--primary),var(--secondary))'],
    ];
}

function delivery_types(): array
{
    return [
        'manual' => ['🧑‍💼', 'تحویل دستی', 'بعد از تایید پرداخت، خودت از صفحه‌ی سفارش تحویل می‌دی (متن، کد یا پیام)'],
        'ship' => ['🚚', 'ارسال پستی', 'کالای فیزیکی؛ آدرس و روش ارسال از مشتری گرفته می‌شه و کد رهگیری براش می‌ره'],
        'codes' => ['⚡', 'کد خودکار', 'کدها رو یکی‌یکی وارد کن؛ بعد از تایید پرداخت، هر خریدار کد خودش رو خودکار می‌گیره'],
        'link' => ['🔗', 'لینک / فایل خودکار', 'بعد از تایید پرداخت، لینک دانلود یا متنی که می‌نویسی خودکار به خریدار نشون داده می‌شه'],
    ];
}

function order_statuses(): array
{
    return [
        'pending_payment' => ['name' => 'در انتظار پرداخت', 'icon' => '💳', 'tone' => 'warn'],
        'reviewing' => ['name' => 'در حال بررسی فیش', 'icon' => '🔎', 'tone' => 'info'],
        'rejected' => ['name' => 'فیش تایید نشد', 'icon' => '⚠️', 'tone' => 'error'],
        'approved' => ['name' => 'پرداخت تایید شد — در حال انجام', 'icon' => '⚙️', 'tone' => 'info'],
        'completed' => ['name' => 'انجام شد', 'icon' => '✅', 'tone' => 'success'],
        'canceled' => ['name' => 'لغو شد', 'icon' => '✖️', 'tone' => 'muted'],
        'expired' => ['name' => 'منقضی شد', 'icon' => '⌛', 'tone' => 'muted'],
    ];
}

/** تم‌های آماده — group: base | pro | occasion · fx: افکت پس‌زمینه پیشنهادی · decor: افکت مناسبتی */
function theme_presets(): array
{
    $t = fn($name, $desc, $p, $s, $bg, $group = 'base', $fx = null, $decor = null, $light = false) => compact('name', 'desc', 'group', 'fx', 'decor', 'light') + ['primary' => $p, 'secondary' => $s, 'bg' => $bg];
    return [
        // ---------- اصلی
        'nexus' => $t('Nexus Red', 'قرمز نئونی — تم اصلی کانال', '#ff1f3d', '#ff7a3d', '#050507', 'base', 'particles'),
        'blood' => $t('Blood Moon', 'قرمز تیره و سینمایی', '#c3002f', '#ff2e63', '#070304', 'base', 'embers'),
        'cyber' => $t('Cyber Blue', 'آبی سایبرپانک', '#00e1ff', '#7c4dff', '#03060d', 'base', 'grid'),
        'toxic' => $t('Toxic Green', 'سبز ماتریکسی', '#39ff14', '#00ffa3', '#030805', 'base', 'matrix'),
        'royal' => $t('Royal Purple', 'بنفش و صورتی نئون', '#b14dff', '#ff3df2', '#06030b', 'base', 'bokeh'),
        'gold' => $t('Golden Hour', 'طلایی و نارنجی گرم', '#ffc53d', '#ff7a1f', '#080602', 'base', 'fireflies'),
        'ocean' => $t('Deep Ocean', 'فیروزه‌ای آرام', '#1de9b6', '#2979ff', '#020a0c', 'base', 'waves'),
        'snow' => $t('Snow Glass', 'تم روشن شیشه‌ای', '#e0102e', '#ff6a3d', '#eef0f6', 'base', 'none', null, true),
        // ---------- حرفه‌ای
        'synthwave' => $t('Synthwave 84', 'صورتی و فیروزه‌ای دهه ۸۰', '#ff2e97', '#00e5ff', '#0b0420', 'pro', 'grid'),
        'vapor' => $t('Vaporwave', 'پاستلی نئونی رویایی', '#ff71ce', '#01cdfe', '#100322', 'pro', 'bokeh'),
        'tokyo' => $t('Neon Tokyo', 'شب‌های بارانی توکیو', '#ff003c', '#00f0ff', '#06060c', 'pro', 'rain'),
        'galaxy' => $t('Galaxy', 'کهکشان بنفش و صورتی', '#8a5cff', '#ff4ecd', '#05030f', 'pro', 'stars'),
        'nebula' => $t('Nebula', 'سحابی آبی و ارغوانی', '#4d7cff', '#c84dff', '#03041a', 'pro', 'nebula'),
        'lava' => $t('Lava Core', 'گدازه‌ی نارنجی و زرد', '#ff4d00', '#ffd000', '#0a0402', 'pro', 'embers'),
        'arctic' => $t('Arctic Ice', 'یخی و کریستالی', '#7ff0ff', '#4d7cff', '#020812', 'pro', 'stars'),
        'emerald' => $t('Emerald Luxe', 'زمرد و طلا — لوکس', '#00d68f', '#d4af37', '#02100a', 'pro', 'fireflies'),
        'crimson' => $t('Royal Crimson', 'زرشکی و طلایی سلطنتی', '#d0103a', '#d4af37', '#0b0406', 'pro', 'bokeh'),
        'sunset' => $t('Sunset Drive', 'غروب نارنجی و صورتی', '#ff5f6d', '#ffc371', '#120608', 'pro', 'waves'),
        'hacker' => $t('Hacker Terminal', 'ترمینال سبز کلاسیک', '#00ff66', '#a3ff12', '#010402', 'pro', 'matrix'),
        'carbon' => $t('Carbon Mono', 'سیاه و نقره‌ای مینیمال', '#e8e8ea', '#8a8f98', '#0a0a0b', 'pro', 'hex'),
        'aurora' => $t('Aurora Borealis', 'شفق قطبی سبز و بنفش', '#00ffa3', '#7c4dff', '#020a10', 'pro', 'aurora'),
        'pearl' => $t('Pearl Light', 'روشن و مرواریدی', '#6b4dff', '#00b3ff', '#f4f5fb', 'pro', 'none', null, true),
        'sakura' => $t('Sakura Light', 'روشن صورتی شکوفه‌ای', '#e8467c', '#ff9e7a', '#fff4f7', 'pro', 'bokeh', null, true),
        // ---------- استودیویی
        'midnight' => $t('Midnight Pro', 'سرمه‌ای و بنفش آرام — حرفه‌ای', '#5b8cff', '#9b6bff', '#050816', 'studio', 'mesh'),
        'mono' => $t('Mono Noir', 'سیاه و سفید خالص — مینیمال', '#ffffff', '#a1a1aa', '#000000', 'studio', 'dots'),
        'mint' => $t('Mint Fresh', 'نعنایی و لیمویی تازه', '#2dd4bf', '#a3e635', '#03110f', 'studio', 'topo'),
        'coral' => $t('Coral Reef', 'مرجانی و هلویی گرم', '#ff6b6b', '#ffb86b', '#12070a', 'studio', 'beams'),
        'electric' => $t('Electric Violet', 'بنفش برقی و فیروزه‌ای', '#8b5cf6', '#22d3ee', '#07041a', 'studio', 'circuit'),
        'espresso' => $t('Espresso', 'قهوه‌ای و کرم گرم — کافه‌ای', '#c08457', '#f2c48d', '#0d0805', 'studio', 'spotlight'),
        'cloud' => $t('Cloud Light', 'روشن آبی و آسمانی', '#2563eb', '#06b6d4', '#f3f6fc', 'studio', 'dots', null, true),
        'sand' => $t('Desert Sand', 'روشن کرم و نارنجی خاکی', '#c2410c', '#d97706', '#faf6ef', 'studio', 'topo', null, true),
        // ---------- مناسبتی
        'nowruz' => $t('نوروز', 'بهار، سبزه و شکوفه 🌸', '#2ecc71', '#ff6fa5', '#04120a', 'occasion', 'bokeh', 'petals'),
        'sizdah' => $t('سیزده‌بدر', 'طبیعت و سبزه 🌿', '#7bd34a', '#ffd23d', '#061205', 'occasion', 'fireflies', 'leaves_green'),
        'yalda' => $t('شب یلدا', 'بلندترین شب — انار و هندوانه 🍉', '#c3002f', '#ff8a3d', '#0b0306', 'occasion', 'stars', 'yalda'),
        'suri' => $t('چهارشنبه‌سوری', 'آتش و جرقه 🔥', '#ff5500', '#ffcc00', '#0a0300', 'occasion', 'embers', 'embers'),
        'halloween' => $t('هالووین', 'نارنجی و بنفش ترسناک 🎃', '#ff7518', '#9b30ff', '#0a0612', 'occasion', 'fireflies', 'halloween'),
        'christmas' => $t('کریسمس / سال نو', 'برف، قرمز و سبز 🎄', '#e0242f', '#1fa35a', '#050b08', 'occasion', 'stars', 'snow'),
        'winter' => $t('زمستان', 'برف و آبی یخی ❄️', '#9fd8ff', '#ffffff', '#04080f', 'occasion', 'stars', 'snow'),
        'autumn' => $t('پاییز', 'برگ‌های نارنجی ریزان 🍁', '#ff8c1a', '#c0392b', '#0e0703', 'occasion', 'fireflies', 'leaves'),
        'valentine' => $t('ولنتاین / سپندارمذگان', 'عشق و قلب‌های صورتی 💖', '#ff2e63', '#ff8fb1', '#12040a', 'occasion', 'bokeh', 'hearts'),
        'ramadan' => $t('رمضان', 'هلال ماه و فانوس طلایی 🌙', '#d4af37', '#1de9b6', '#03100e', 'occasion', 'stars', 'ramadan'),
        'eid' => $t('عید فطر / قربان', 'سبز و طلایی جشن ✨', '#3ddc84', '#ffd24d', '#03100a', 'occasion', 'fireflies', 'sparkles'),
        'muharram' => $t('محرم', 'مشکی و سبز — آرام و بی‌جلوه', '#2e9e5b', '#9aa0a6', '#040606', 'occasion', 'none', null),
        // ---------- دلخواه
        'custom' => ['name' => 'سفارشی', 'desc' => 'رنگ‌های دلخواه خودت', 'group' => 'base', 'fx' => null, 'decor' => null, 'primary' => null, 'secondary' => null, 'bg' => null, 'light' => false],
    ];
}

function theme_groups(): array
{
    return ['base' => '🎨 تم‌های اصلی', 'pro' => '💎 تم‌های حرفه‌ای', 'studio' => '🖤 تم‌های استودیویی (جدید)', 'occasion' => '🎉 تم‌های مناسبتی'];
}

function card_styles(): array
{
    return [
        'glass' => ['شیشه‌ای', 'مات و شفاف با بلور'], 'solid' => ['توپر', 'سبک و سریع‌تر'], 'outline' => ['خطی', 'فقط حاشیه'],
        'neon' => ['نئونی', 'درخشش رنگی دور کارت'], 'gradient' => ['حاشیه گرادیانی', 'حاشیه‌ی رنگین براق'], 'holo' => ['هولوگرافیک', 'برق رنگین‌کمانی روی کارت'],
        'cyber' => ['سایبری', 'گوشه‌های بریده‌ی HUD'], 'elevated' => ['سه‌بعدی', 'سایه‌ی عمیق و برجسته'], 'frost' => ['یخی مات', 'بلور غلیظ و نرم'],
        'bento' => ['بنتو', 'کاشی‌های نرم با نوار رنگی بالا'], 'aurora' => ['لبه‌ی شفق', 'حاشیه‌ی رنگین‌کمانی ملایم'],
        'minimal' => ['مینیمال', 'بی‌حاشیه، تمیز و آرام'], 'duo' => ['دوتونه', 'ته‌رنگ دو رنگ تم روی کارت'],
    ];
}

function bg_effects(): array
{
    return [
        'particles' => ['شبکه ذرات', 'ذرات متصل متحرک (تعاملی با موس)'], 'matrix' => ['ماتریکس', 'باران کاراکترهای سایبری'],
        'grid' => ['گرید سایبری', 'شبکه سه‌بعدی متحرک'], 'aurora' => ['شفق قطبی', 'نور چرخان ملایم'],
        'stars' => ['سفر بین ستاره‌ها', 'ستاره‌هایی که به سمتت می‌آیند'], 'waves' => ['امواج نئونی', 'موج‌های نرم و روان'],
        'bokeh' => ['بوکه', 'دایره‌های نورانی محو'], 'fireflies' => ['کرم شب‌تاب', 'نقطه‌های درخشان شناور'],
        'embers' => ['جرقه و آتش', 'جرقه‌های بالارونده'], 'rain' => ['باران نئونی', 'خطوط باران سایبرپانکی'],
        'nebula' => ['سحابی', 'ابرهای رنگی کهکشانی'], 'hex' => ['شش‌ضلعی', 'شبکه‌ی کندوی تپنده'],
        'mesh' => ['گرادیان مش', 'رنگ‌های نرم که آروم در هم می‌رن'], 'circuit' => ['مدار الکترونیکی', 'خطوط مدار با پالس نوری'],
        'dots' => ['شبکه‌ی نقطه‌ای', 'نقطه‌های ریز با نور ملایم'], 'beams' => ['پرتوهای نور', 'نورهای مورب که آروم رد می‌شن'],
        'topo' => ['خطوط توپوگرافی', 'خطوط نقشه‌ای موج‌دار'], 'spotlight' => ['نورافکن', 'دو نورافکن صحنه‌ای چرخان'],
        'none' => ['ساده', 'فقط هاله‌های رنگی'],
    ];
}

/** افکت‌های مناسبتی (ذرات ریزان) */
function decor_types(): array
{
    return [
        'snow' => 'برف ❄️', 'petals' => 'شکوفه 🌸', 'hearts' => 'قلب 💖', 'halloween' => 'خفاش و کدو 🎃', 'leaves' => 'برگ پاییزی 🍁',
        'leaves_green' => 'برگ سبز 🌿', 'yalda' => 'یلدا 🍉', 'embers' => 'جرقه 🔥', 'ramadan' => 'هلال و ستاره 🌙', 'sparkles' => 'درخشش ✨',
    ];
}

/** جایگاه‌های تبلیغ */
function ad_positions(): array
{
    return [
        'header_top' => ['name' => 'بالای هدر (نوار سراسری)', 'hint' => 'یه خط باریک بالای همه صفحات با دکمه‌ی بستن — متن کوتاه بنویس', 'size' => 'یک خط'],
        'home_top' => ['name' => 'صفحه اصلی — زیر اسلایدر', 'hint' => 'بنر عریض بعد از بخش ویژه', 'size' => '1200×200'],
        'home_middle' => ['name' => 'صفحه اصلی — وسط (بعد از اولین بلوک دسته)', 'hint' => 'بعد از اولین بلوک دسته‌بندی (مثلاً بعد از «گیم»)', 'size' => '1200×200'],
        'sidebar' => ['name' => 'سایدبار', 'hint' => 'کنار اخبار و صفحه خبر', 'size' => '400×400'],
        'post_top' => ['name' => 'خبر — بالای متن', 'hint' => 'قبل از شروع متن خبر', 'size' => '800×150'],
        'post_middle' => ['name' => 'خبر — وسط متن', 'hint' => 'بعد از پاراگراف N ام', 'size' => '800×150'],
        'post_bottom' => ['name' => 'خبر — پایان متن', 'hint' => 'بعد از متن و قبل از نظرات', 'size' => '800×200'],
        'footer_top' => ['name' => 'بالای فوتر', 'hint' => 'در همه صفحات', 'size' => '1200×150'],
        'popup' => ['name' => 'پاپ‌آپ (پنجره شناور)', 'hint' => 'با تاخیر و تکرار قابل تنظیم', 'size' => '600×400'],
        'floating' => ['name' => 'نوار شناور پایین صفحه', 'hint' => 'چسبان به پایین، قابل بستن', 'size' => '728×90'],
    ];
}

/** تم‌های تبلیغ */
function ad_themes(): array
{
    return [
        'neon' => ['name' => 'Neon Pulse', 'desc' => 'حاشیه‌ی نئونی تپنده'],
        'glass' => ['name' => 'Glass Shine', 'desc' => 'شیشه‌ای با برق عبوری'],
        'flow' => ['name' => 'Gradient Flow', 'desc' => 'حاشیه‌ی گرادیانی چرخان'],
        'glitch' => ['name' => 'Cyber Glitch', 'desc' => 'گلیچ سایبری با اسکن‌لاین'],
        'holo' => ['name' => 'Holographic', 'desc' => 'هولوگرافیک رنگین‌کمانی'],
        'aurora' => ['name' => 'Aurora', 'desc' => 'شفق قطبی متحرک'],
        'fire' => ['name' => 'Fire Embers', 'desc' => 'ذرات آتش در حال صعود'],
        'spotlight' => ['name' => 'Spotlight', 'desc' => 'نورافکن دنبال‌کننده‌ی موس'],
        'ribbon' => ['name' => 'VIP Ribbon', 'desc' => 'روبان ویژه گوشه'],
        'minimal' => ['name' => 'Minimal', 'desc' => 'ساده و تمیز'],
    ];
}

function ad_formats(): array
{
    return [
        'card' => 'کارت متنی (ایموجی، عنوان، متن، دکمه، تصویر اختیاری)',
        'image' => 'بنر تصویری',
        'html' => 'کد HTML / اسکریپت (یکتانت، گوگل و ...)',
    ];
}

function sidebar_widget_names(): array
{
    return ['trend' => '🔥 داغ‌ترین‌ها (پربازدید)', 'ads' => '📢 تبلیغات و باکس‌های سایدبار', 'telegram' => '✈️ کارت «عضویت در کانال»', 'tags' => '🏷️ برچسب‌های داغ'];
}

/** sidebar widgets in the saved order, with any new widget added at the end (switched on) */
function sidebar_widgets(): array
{
    $l = setting_json('sidebar_widgets') ?: json_decode(default_settings()['sidebar_widgets'], true);
    $names = sidebar_widget_names(); $out = []; $seen = [];
    foreach ((array) $l as $w) if (is_array($w) && isset($names[$w['key'] ?? '']) && !isset($seen[$w['key']])) { $out[] = ['key' => $w['key'], 'on' => !empty($w['on']) ? 1 : 0]; $seen[$w['key']] = 1; }
    foreach ($names as $k => $n) if (!isset($seen[$k])) $out[] = ['key' => $k, 'on' => 1];
    return $out;
}

function home_section_names(): array
{
    return [
        'hero' => 'بخش ویژه (اسلایدر / مجله‌ای)',
        'latest' => 'آخرین اخبار + سایدبار',
        'categories' => 'بلوک دسته‌بندی‌ها',
        'trending' => 'پربازدیدترین‌ها',
        'telegram' => 'دعوت به کانال تلگرام',
        'shop' => 'بنر فروشگاه + محصولات ویژه',
    ];
}
